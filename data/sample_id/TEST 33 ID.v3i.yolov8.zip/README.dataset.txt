# TEST 33 ID > 2024-09-16 9:38am
https://universe.roboflow.com/brain-house/test-33-id

Provided by a Roboflow user
License: CC BY 4.0

